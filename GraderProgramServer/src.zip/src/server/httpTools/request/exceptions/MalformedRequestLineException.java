package server.httpTools.request.exceptions;


public class MalformedRequestLineException extends MalformedRequestException {
    
}
