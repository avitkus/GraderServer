package server.httpTools.request.exceptions;

/**
 * 
 * @author Andrew Vitkus
 */
public class IllegalBoundaryException extends MalformedRequestException {
    
}
