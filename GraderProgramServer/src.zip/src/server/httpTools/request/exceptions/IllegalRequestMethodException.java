package server.httpTools.request.exceptions;


public class IllegalRequestMethodException extends MalformedRequestLineException {
    
}
