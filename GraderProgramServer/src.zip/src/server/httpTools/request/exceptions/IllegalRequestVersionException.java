package server.httpTools.request.exceptions;


public class IllegalRequestVersionException extends MalformedRequestLineException {
    
}
