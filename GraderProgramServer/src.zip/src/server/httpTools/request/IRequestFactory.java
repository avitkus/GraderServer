package server.httpTools.request;

/**
 *
 * @author Andrew Vitkus
 */
public interface IRequestFactory {
    public IRequest buildRequest();
}
