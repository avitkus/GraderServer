package server.httpTools.request;

/**
 *
 * @author Andrew Vitkus
 */
public interface IRequestBody {
    public String getBody();
}
