package server.httpTools.util;

/**
 *
 * @author Andrew Vitkus
 */
public enum HTTPMethod {
    OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT, PATCH;
}
