package server.com.webHandler.pages.parts;

import server.htmlBuilder.meta.INavigationBar;

/**
 *
 * @author Andrew
 */
public interface IStudentDataNavBar extends INavigationBar {
}
