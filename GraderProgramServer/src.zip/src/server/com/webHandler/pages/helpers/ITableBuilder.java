package server.com.webHandler.pages.helpers;

import server.htmlBuilder.table.ITable;

/**
 *
 * @author Andrew Vitkus
 */
public interface ITableBuilder {
    public ITable getTable();
}
