package server.com.webHandler.pages.css;

import server.cssBuilder.ICSSFile;

/**
 * @author Andrew Vitkus
 *
 */
public interface IAuthCSS extends ICSSFile {

}
