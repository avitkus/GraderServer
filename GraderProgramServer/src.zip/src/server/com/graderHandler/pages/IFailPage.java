package server.com.graderHandler.pages;

import server.htmlBuilder.IHTMLFile;

/**
 *
 * @author Andrew Vitkus
 */
public interface IFailPage extends IGraderResponsePage {
}
