package server.com.graderHandler.util;

/**
 *
 * @author Andrew Vitkus
 */
public interface ICSVGradeWriter extends IGradeWriter {
    
}
