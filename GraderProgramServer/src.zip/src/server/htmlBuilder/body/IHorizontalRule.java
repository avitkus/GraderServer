package server.htmlBuilder.body;

import server.htmlBuilder.util.IColorable;

/**
 * @author Andrew Vitkus
 *
 */
public interface IHorizontalRule extends IBodyElement, IColorable {

}
