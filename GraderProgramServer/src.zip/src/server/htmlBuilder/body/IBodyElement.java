package server.htmlBuilder.body;

import server.htmlBuilder.IHTMLElement;

/**
 * @author Andrew Vitkus
 *
 */
@SuppressWarnings("MarkerInterface")
public interface IBodyElement extends IHTMLElement {
}
