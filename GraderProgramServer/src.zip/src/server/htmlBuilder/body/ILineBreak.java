package server.htmlBuilder.body;

/**
 * @author Andrew Vitkus
 *
 */
public interface ILineBreak extends IBodyElement {

}
