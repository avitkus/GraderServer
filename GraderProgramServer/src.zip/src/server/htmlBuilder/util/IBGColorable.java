package server.htmlBuilder.util;

/**
 * @author Andrew Vitkus
 *
 */
public interface IBGColorable extends IStylable {
	public void setBGColor(String color);
	public String getBGColor();
}
