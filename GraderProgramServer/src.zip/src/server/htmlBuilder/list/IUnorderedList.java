package server.htmlBuilder.list;

/**
 * @author Andrew Vitkus
 *
 */
public interface IUnorderedList extends IList {
}
