package server.htmlBuilder.table;

import server.htmlBuilder.util.IColorable;

/**
 * @author Andrew Vitkus
 *
 */
public interface ITableHeader extends ITableData, IColorable {
}
