package server.htmlBuilder.doctype;

import server.htmlBuilder.ITag;

/**
 * @author Andrew Vitkus
 *
 */
public interface IDoctype extends ITag {
}
