package server.htmlBuilder.form.input;

import server.htmlBuilder.form.input.IButton;

/**
 * @author Andrew Vitkus
 *
 */
public interface ISubmitButton extends IButton {

}
