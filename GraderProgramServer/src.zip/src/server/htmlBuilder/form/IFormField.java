package server.htmlBuilder.form;

import server.htmlBuilder.body.IBodyElement;

/**
 * @author Andrew Vitkus
 *
 */
public interface IFormField extends IBodyElement, IFormElement{

}
