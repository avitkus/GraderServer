package server.htmlBuilder.form;

import server.htmlBuilder.body.IBodyElement;

/**
 * @author Andrew Vitkus
 *
 */
public interface IFormElement extends IBodyElement {

}
