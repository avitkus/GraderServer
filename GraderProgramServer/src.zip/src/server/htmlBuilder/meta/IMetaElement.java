package server.htmlBuilder.meta;

import server.htmlBuilder.body.IBodyElement;

/**
 *
 * @author Andrew Vitkus
 */
public interface IMetaElement extends IBodyElement {
    
}
