package server.htmlBuilder.attributes;

/**
 * @author Andrew Vitkus
 *
 */
public enum TextSize {
	NORMAL, H1, H2, H3, H4, H5, H6
}
