package server.htmlBuilder.attributes;

/**
 * @author Andrew Vitkus
 *
 */
public enum TextStyle {
	PLAIN, BOLD, ITALIC, UNDERLINE, SUPERSCRIPT, SUBSCRIPT, CODE
}
