package server.htmlBuilder.head;

import server.htmlBuilder.IHTMLElement;

/**
 * @author Andrew Vitkus
 *
 */
public interface IHeadElement extends IHTMLElement {

}
