package server.htmlBuilder.head;

/**
 * @author Andrew Vitkus
 *
 */
public interface ITitle extends IHeadElement {
	public String getTitle();
	public void setTitle(String title);
}
